from Flag import DataFrame

res = [34, 88, 205, 160, 220, 83, 10, 177, 84, 202, 92, 236, 170, 160, 226, 98, 63, 118, 177, 33, 188, 125, 192, 27, 240, 214, 205, 211, 255, 28, 247, 36, 195, 0, 158, 144, 153, 34, 80, 87, 45, 40, 125, 106, 214, 6, 187, 93, 189, 13, 61, 70, 43, 65, 180, 175, 52, 97, 144, 233, 125, 76, 60, 66]

def get_user_data():
    user = DataFrame(input('[Enter your flag] >>> ').encode())
    return user

if __name__ == '__main__':
    user = get_user_data()
    enc_data = user.enc()
    print(enc_data)

    is_ok = True
    for i in range(len(res)):
        if enc_data[i] != res[i]:
            is_ok = False
    if is_ok:
        print('Correct!')
    else:
        print('Wrong!')
