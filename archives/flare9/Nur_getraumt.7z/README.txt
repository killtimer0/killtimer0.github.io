This challenge is a Macintosh disk image (Disk Copy 4.2 format, for those who need to
know) containing a 68K Macintosh program.  You must determine the passphrase used to
decode the flag contained within the application.  Super ResEdit, an augmented version of
Apple's ResEdit resource editor which adds a disassembler, is also included on the disk
image to help you complete the challenge, though you will likely also need to do some
outside research to guess the passphrase.

This application can be run on any Macintosh emulator (or any real Macintosh from as far
back as a Mac Plus running System 6.0.x up to a G5 running Classic).  The setup of the
emulation environment is part of the challenge, so few spoilers live here, but if you
want to save yourself some headaches, Mini vMac is a pretty good choice that doesn't take
much effort to get up and running compared to some other options.

This application was written on a Power Macintosh 7300 using CodeWarrior Pro 5, ResEdit,
and Resourcerer (my old setup from roughly 1997, still alive!).  It was tested on a great
many machines and emulators, and validated to run well on Mac OS from 6.0.8 through 10.4.

Happy solving!  Be curious!